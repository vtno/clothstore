$(".owl-carousel").owlCarousel({
		navigation : true, // Show next and prev buttons
	    slideSpeed : 300,
	    paginationSpeed : 400,
	    singleItem:true
});
